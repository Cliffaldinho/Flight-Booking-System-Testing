create
    definer = root@localhost procedure UpdateAirlineReviewScore(IN AirlineCodeInput char(2))
BEGIN

SET SQL_SAFE_UPDATES=0;
UPDATE airlines a SET a.AirlineRating = 
(SELECT AVG(`AirlineOverallRating`) FROM AirlineReviews ar WHERE ar.AirlineCode = AirlineCodeInput)
WHERE a.AirlineCode = AirlineCodeInput;
SET SQL_SAFE_UPDATES=1;

END;

